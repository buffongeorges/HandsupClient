export const MenuItems = [
    {
        title: 'Classes',
        url : '/classes',
        cName: 'nav-links',
    },
    {
        title: 'Settings',
        url : '/settings',
        cName: 'nav-links',
    },
    {
        title: 'Sign Up',
        url : '/signup',
        cName: 'nav-links-mobile',
    },
]