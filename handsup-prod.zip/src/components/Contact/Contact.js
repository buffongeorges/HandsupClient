import React from "react";
import Button from "react-bootstrap/Button";


export default function Contact() {
 

  return (
    <div className="container"
    style={{
      textAlign: "center",
      position: "relative",
      justifyContent: "center",
      paddingTop: "2rem",
      paddingLeft: "2rem",
    }}>
        {"N'hésitez pas à nous contacter !"}
    </div>
  );
}
